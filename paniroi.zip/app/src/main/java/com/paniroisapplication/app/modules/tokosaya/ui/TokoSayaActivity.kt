package com.paniroisapplication.app.modules.tokosaya.ui

import android.view.View
import androidx.activity.viewModels
import com.paniroisapplication.app.R
import com.paniroisapplication.app.appcomponents.base.BaseActivity
import com.paniroisapplication.app.databinding.ActivityTokoSayaBinding
import com.paniroisapplication.app.modules.tokosaya.`data`.model.TokoSayaRowModel
import com.paniroisapplication.app.modules.tokosaya.`data`.viewmodel.TokoSayaVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class TokoSayaActivity : BaseActivity<ActivityTokoSayaBinding>(R.layout.activity_toko_saya) {
  private val viewModel: TokoSayaVM by viewModels<TokoSayaVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val tokoSayaAdapter = TokoSayaAdapter(viewModel.tokoSayaList.value?:mutableListOf())
    binding.recyclerTokoSaya.adapter = tokoSayaAdapter
    tokoSayaAdapter.setOnItemClickListener(
    object : TokoSayaAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : TokoSayaRowModel) {
        onClickRecyclerTokoSaya(view, position, item)
      }
    }
    )
    viewModel.tokoSayaList.observe(this) {
      tokoSayaAdapter.updateData(it)
    }
    binding.tokoSayaVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  fun onClickRecyclerTokoSaya(
    view: View,
    position: Int,
    item: TokoSayaRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "TOKO_SAYA_ACTIVITY"

  }
}
