package com.paniroisapplication.app.modules.tokosaya.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.paniroisapplication.app.modules.tokosaya.`data`.model.TokoSayaModel
import com.paniroisapplication.app.modules.tokosaya.`data`.model.TokoSayaRowModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class TokoSayaVM : ViewModel(), KoinComponent {
  val tokoSayaModel: MutableLiveData<TokoSayaModel> = MutableLiveData(TokoSayaModel())

  var navArguments: Bundle? = null

  val tokoSayaList: MutableLiveData<MutableList<TokoSayaRowModel>> =
      MutableLiveData(mutableListOf())
}
