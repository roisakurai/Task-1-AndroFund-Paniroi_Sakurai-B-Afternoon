package com.paniroisapplication.app.modules.dashboardvendor.`data`.model

import com.paniroisapplication.app.R
import com.paniroisapplication.app.appcomponents.di.MyApp
import kotlin.String

data class DashboardVendorModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtDashboardToko: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_dashboard_toko)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCloserWedding: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_closer_wedding)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtProfilSaya: String? = MyApp.getInstance().resources.getString(R.string.lbl_profil_saya)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt4650: String? = MyApp.getInstance().resources.getString(R.string.lbl_4_6_5_0)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtProdukCounter: String? = MyApp.getInstance().resources.getString(R.string.lbl_6_produk)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFour: String? = MyApp.getInstance().resources.getString(R.string.lbl)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPembeliCounter: String? = MyApp.getInstance().resources.getString(R.string.lbl_124_pembeli)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFive: String? = MyApp.getInstance().resources.getString(R.string.lbl)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPengikutCounter: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_42_pengikut)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtStatusPesanan: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_status_pesanan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGroup13984: String? = MyApp.getInstance().resources.getString(R.string.lbl_3)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPerluDiselesai: String? =
      MyApp.getInstance().resources.getString(R.string.msg_perlu_diselesai)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGroup13984One: String? = MyApp.getInstance().resources.getString(R.string.lbl_1)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPerluDikonfirm: String? =
      MyApp.getInstance().resources.getString(R.string.msg_perlu_dikonfirm)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGroup13984Two: String? = MyApp.getInstance().resources.getString(R.string.lbl_0)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDibatalkan: String? = MyApp.getInstance().resources.getString(R.string.lbl_dibatalkan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGroup13984Three: String? = MyApp.getInstance().resources.getString(R.string.lbl_7)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPenilaianPerlu: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_penilaian_perlu)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDibalas: String? = MyApp.getInstance().resources.getString(R.string.lbl_dibalas)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtProduk: String? = MyApp.getInstance().resources.getString(R.string.lbl_produk)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtKeuangan: String? = MyApp.getInstance().resources.getString(R.string.lbl_keuangan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtToko: String? = MyApp.getInstance().resources.getString(R.string.lbl_toko)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtData: String? = MyApp.getInstance().resources.getString(R.string.lbl_data)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPromosi: String? = MyApp.getInstance().resources.getString(R.string.lbl_promosi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLayananPembeli: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_layanan_pembeli)

)
