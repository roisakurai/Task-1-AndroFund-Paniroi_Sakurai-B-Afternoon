package com.paniroisapplication.app.modules.dashboardvendor.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.paniroisapplication.app.modules.dashboardvendor.`data`.model.DashboardVendorModel
import com.paniroisapplication.app.modules.dashboardvendor.`data`.model.ListquestionRowModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class DashboardVendorVM : ViewModel(), KoinComponent {
  val dashboardVendorModel: MutableLiveData<DashboardVendorModel> =
      MutableLiveData(DashboardVendorModel())

  var navArguments: Bundle? = null

  val listquestionList: MutableLiveData<MutableList<ListquestionRowModel>> =
      MutableLiveData(mutableListOf())
}
