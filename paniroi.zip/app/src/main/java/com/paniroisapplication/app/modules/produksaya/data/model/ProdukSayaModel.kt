package com.paniroisapplication.app.modules.produksaya.`data`.model

import com.paniroisapplication.app.R
import com.paniroisapplication.app.appcomponents.di.MyApp
import kotlin.String

data class ProdukSayaModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtProdukSaya: String? = MyApp.getInstance().resources.getString(R.string.lbl_produk_saya)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTambahProdukB: String? =
      MyApp.getInstance().resources.getString(R.string.msg_tambah_produk_b)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPopuler: String? = MyApp.getInstance().resources.getString(R.string.lbl_populer)

)
