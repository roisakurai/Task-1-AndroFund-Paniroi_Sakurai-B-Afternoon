package com.paniroisapplication.app.modules.dashboardvendor.ui

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import com.paniroisapplication.app.R
import com.paniroisapplication.app.appcomponents.base.BaseFragment
import com.paniroisapplication.app.databinding.FragmentDashboardVendorBinding
import com.paniroisapplication.app.modules.dashboardvendor.`data`.model.ListquestionRowModel
import com.paniroisapplication.app.modules.dashboardvendor.`data`.viewmodel.DashboardVendorVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class DashboardVendorFragment :
    BaseFragment<FragmentDashboardVendorBinding>(R.layout.fragment_dashboard_vendor) {
  private val viewModel: DashboardVendorVM by viewModels<DashboardVendorVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    val listquestionAdapter =
    ListquestionAdapter(viewModel.listquestionList.value?:mutableListOf())
    binding.recyclerListquestion.adapter = listquestionAdapter
    listquestionAdapter.setOnItemClickListener(
    object : ListquestionAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ListquestionRowModel) {
        onClickRecyclerListquestion(view, position, item)
      }
    }
    )
    viewModel.listquestionList.observe(requireActivity()) {
      listquestionAdapter.updateData(it)
    }
    binding.dashboardVendorVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      requireActivity().onBackPressed()
    }
  }

  fun onClickRecyclerListquestion(
    view: View,
    position: Int,
    item: ListquestionRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "DASHBOARD_VENDOR_FRAGMENT"


    fun getInstance(bundle: Bundle?): DashboardVendorFragment {
      val fragment = DashboardVendorFragment()
      fragment.arguments = bundle
      return fragment
    }
  }
}
