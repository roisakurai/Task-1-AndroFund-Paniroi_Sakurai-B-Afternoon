package com.paniroisapplication.app.modules.keuangansaya.`data`.model

import com.paniroisapplication.app.R
import com.paniroisapplication.app.appcomponents.di.MyApp
import kotlin.String

data class KeuanganSayaRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtFour: String? = MyApp.getInstance().resources.getString(R.string.lbl_04)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt130000: String? = MyApp.getInstance().resources.getString(R.string.lbl_130_000)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGaunPengantin: String? =
      MyApp.getInstance().resources.getString(R.string.msg_gaun_pengantin)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt50000: String? = MyApp.getInstance().resources.getString(R.string.lbl_50_000)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRabu: String? = MyApp.getInstance().resources.getString(R.string.lbl_rabu)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtOktoberCounter: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_oktober_2023)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBunga: String? = MyApp.getInstance().resources.getString(R.string.lbl_bunga)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt30000: String? = MyApp.getInstance().resources.getString(R.string.lbl_30_000)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtJas: String? = MyApp.getInstance().resources.getString(R.string.lbl_jas)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt50000One: String? = MyApp.getInstance().resources.getString(R.string.lbl_50_000)

)
