package com.paniroisapplication.app.modules.datasaya.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.paniroisapplication.app.modules.datasaya.`data`.model.DataSayaModel
import org.koin.core.KoinComponent

class DataSayaVM : ViewModel(), KoinComponent {
  val dataSayaModel: MutableLiveData<DataSayaModel> = MutableLiveData(DataSayaModel())

  var navArguments: Bundle? = null
}
