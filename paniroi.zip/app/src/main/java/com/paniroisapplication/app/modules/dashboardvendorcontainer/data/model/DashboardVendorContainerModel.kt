package com.paniroisapplication.app.modules.dashboardvendorcontainer.`data`.model

class DashboardVendorContainerModel()
