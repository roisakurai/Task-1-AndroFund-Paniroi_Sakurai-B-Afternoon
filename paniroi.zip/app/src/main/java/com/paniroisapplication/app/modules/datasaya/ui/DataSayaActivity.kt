package com.paniroisapplication.app.modules.datasaya.ui

import androidx.activity.viewModels
import com.paniroisapplication.app.R
import com.paniroisapplication.app.appcomponents.base.BaseActivity
import com.paniroisapplication.app.databinding.ActivityDataSayaBinding
import com.paniroisapplication.app.modules.datasaya.`data`.viewmodel.DataSayaVM
import kotlin.String
import kotlin.Unit

class DataSayaActivity : BaseActivity<ActivityDataSayaBinding>(R.layout.activity_data_saya) {
  private val viewModel: DataSayaVM by viewModels<DataSayaVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.dataSayaVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  companion object {
    const val TAG: String = "DATA_SAYA_ACTIVITY"

  }
}
