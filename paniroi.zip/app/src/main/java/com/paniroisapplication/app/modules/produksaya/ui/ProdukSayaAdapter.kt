package com.paniroisapplication.app.modules.produksaya.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.paniroisapplication.app.R
import com.paniroisapplication.app.databinding.RowProdukSayaBinding
import com.paniroisapplication.app.modules.produksaya.`data`.model.ProdukSayaRowModel
import kotlin.Int
import kotlin.collections.List

class ProdukSayaAdapter(
  var list: List<ProdukSayaRowModel>
) : RecyclerView.Adapter<ProdukSayaAdapter.RowProdukSayaVH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowProdukSayaVH {
    val view=LayoutInflater.from(parent.context).inflate(R.layout.row_produk_saya,parent,false)
    return RowProdukSayaVH(view)
  }

  override fun onBindViewHolder(holder: RowProdukSayaVH, position: Int) {
    val produkSayaRowModel = ProdukSayaRowModel()
    // TODO uncomment following line after integration with data source
    // val produkSayaRowModel = list[position]
    holder.binding.produkSayaRowModel = produkSayaRowModel
  }

  override fun getItemCount(): Int = 4
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<ProdukSayaRowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: ProdukSayaRowModel
    ) {
    }
  }

  inner class RowProdukSayaVH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowProdukSayaBinding = RowProdukSayaBinding.bind(itemView)
  }
}
