package com.paniroisapplication.app.modules.tokosaya.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.paniroisapplication.app.R
import com.paniroisapplication.app.databinding.RowTokoSayaBinding
import com.paniroisapplication.app.modules.tokosaya.`data`.model.TokoSayaRowModel
import kotlin.Int
import kotlin.collections.List

class TokoSayaAdapter(
  var list: List<TokoSayaRowModel>
) : RecyclerView.Adapter<TokoSayaAdapter.RowTokoSayaVH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowTokoSayaVH {
    val view=LayoutInflater.from(parent.context).inflate(R.layout.row_toko_saya,parent,false)
    return RowTokoSayaVH(view)
  }

  override fun onBindViewHolder(holder: RowTokoSayaVH, position: Int) {
    val tokoSayaRowModel = TokoSayaRowModel()
    // TODO uncomment following line after integration with data source
    // val tokoSayaRowModel = list[position]
    holder.binding.tokoSayaRowModel = tokoSayaRowModel
  }

  override fun getItemCount(): Int = 2
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<TokoSayaRowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: TokoSayaRowModel
    ) {
    }
  }

  inner class RowTokoSayaVH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowTokoSayaBinding = RowTokoSayaBinding.bind(itemView)
  }
}
