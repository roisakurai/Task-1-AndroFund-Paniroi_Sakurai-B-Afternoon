package com.paniroisapplication.app.modules.tokosaya.`data`.model

import com.paniroisapplication.app.R
import com.paniroisapplication.app.appcomponents.di.MyApp
import kotlin.String

data class TokoSayaModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtTokoSaya: String? = MyApp.getInstance().resources.getString(R.string.lbl_toko_saya)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPenilaianToko: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_penilaian_toko)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtProfilToko: String? = MyApp.getInstance().resources.getString(R.string.lbl_profil_toko)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtKategoriToko: String? = MyApp.getInstance().resources.getString(R.string.lbl_kategori_toko)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPenilaianTokoOne: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_penilaian_toko)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFortySix: String? = MyApp.getInstance().resources.getString(R.string.lbl_4_6)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFive: String? = MyApp.getInstance().resources.getString(R.string.lbl_5)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSemua: String? = MyApp.getInstance().resources.getString(R.string.lbl_semua)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPerluDibalas: String? = MyApp.getInstance().resources.getString(R.string.lbl_perlu_dibalas)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSudahDibalas: String? = MyApp.getInstance().resources.getString(R.string.lbl_sudah_dibalas)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSemuaOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_semua)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt5Bintang: String? = MyApp.getInstance().resources.getString(R.string.lbl_5_bintang_20)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt4Bintang: String? = MyApp.getInstance().resources.getString(R.string.lbl_4_bintang_5)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt3Bintang: String? = MyApp.getInstance().resources.getString(R.string.lbl_3_bintang_5)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt2Bintang: String? = MyApp.getInstance().resources.getString(R.string.lbl_2_bintang_5)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt1Bintang: String? = MyApp.getInstance().resources.getString(R.string.lbl_2_bintang_5)

)
