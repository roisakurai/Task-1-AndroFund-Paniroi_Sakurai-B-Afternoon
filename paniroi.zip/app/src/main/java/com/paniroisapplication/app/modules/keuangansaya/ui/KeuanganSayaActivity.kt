package com.paniroisapplication.app.modules.keuangansaya.ui

import android.view.View
import androidx.activity.viewModels
import com.paniroisapplication.app.R
import com.paniroisapplication.app.appcomponents.base.BaseActivity
import com.paniroisapplication.app.databinding.ActivityKeuanganSayaBinding
import com.paniroisapplication.app.modules.keuangansaya.`data`.model.KeuanganSayaRowModel
import com.paniroisapplication.app.modules.keuangansaya.`data`.viewmodel.KeuanganSayaVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class KeuanganSayaActivity :
    BaseActivity<ActivityKeuanganSayaBinding>(R.layout.activity_keuangan_saya) {
  private val viewModel: KeuanganSayaVM by viewModels<KeuanganSayaVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val keuanganSayaAdapter =
    KeuanganSayaAdapter(viewModel.keuanganSayaList.value?:mutableListOf())
    binding.recyclerKeuanganSaya.adapter = keuanganSayaAdapter
    keuanganSayaAdapter.setOnItemClickListener(
    object : KeuanganSayaAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : KeuanganSayaRowModel) {
        onClickRecyclerKeuanganSaya(view, position, item)
      }
    }
    )
    viewModel.keuanganSayaList.observe(this) {
      keuanganSayaAdapter.updateData(it)
    }
    binding.keuanganSayaVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  fun onClickRecyclerKeuanganSaya(
    view: View,
    position: Int,
    item: KeuanganSayaRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "KEUANGAN_SAYA_ACTIVITY"

  }
}
