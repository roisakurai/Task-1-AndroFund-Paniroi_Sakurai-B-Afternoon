package com.paniroisapplication.app.modules.produksaya.`data`.model

import com.paniroisapplication.app.R
import com.paniroisapplication.app.appcomponents.di.MyApp
import kotlin.String

data class ProdukSayaRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtGaunPengantin: String? =
      MyApp.getInstance().resources.getString(R.string.msg_gaun_pengantin)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRpCounter: String? = MyApp.getInstance().resources.getString(R.string.lbl_rp_50_000)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt4850: String? = MyApp.getInstance().resources.getString(R.string.lbl_4_8_5_0)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSix: String? = MyApp.getInstance().resources.getString(R.string.lbl)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTerjualCounter: String? = MyApp.getInstance().resources.getString(R.string.lbl_53_terjual)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtStokSix: String? = MyApp.getInstance().resources.getString(R.string.lbl_stok_6)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtKategoriFash: String? = MyApp.getInstance().resources.getString(R.string.msg_kategori_fash)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLihatDetail: String? = MyApp.getInstance().resources.getString(R.string.lbl_lihat_detail)

)
