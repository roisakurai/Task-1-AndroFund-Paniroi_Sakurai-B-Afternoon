package com.paniroisapplication.app.modules.keuangansaya.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.paniroisapplication.app.modules.keuangansaya.`data`.model.KeuanganSayaModel
import com.paniroisapplication.app.modules.keuangansaya.`data`.model.KeuanganSayaRowModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class KeuanganSayaVM : ViewModel(), KoinComponent {
  val keuanganSayaModel: MutableLiveData<KeuanganSayaModel> = MutableLiveData(KeuanganSayaModel())

  var navArguments: Bundle? = null

  val keuanganSayaList: MutableLiveData<MutableList<KeuanganSayaRowModel>> =
      MutableLiveData(mutableListOf())
}
