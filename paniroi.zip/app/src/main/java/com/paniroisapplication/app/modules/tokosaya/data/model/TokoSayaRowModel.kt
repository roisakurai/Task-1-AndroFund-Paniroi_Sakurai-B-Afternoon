package com.paniroisapplication.app.modules.tokosaya.`data`.model

import com.paniroisapplication.app.R
import com.paniroisapplication.app.appcomponents.di.MyApp
import kotlin.String

data class TokoSayaRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtGaunPengantin: String? =
      MyApp.getInstance().resources.getString(R.string.msg_gaun_pengantin)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEightlilacTwentyThreeOne: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_eight_lilac23)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDescription: String? = MyApp.getInstance().resources.getString(R.string.msg_harga_worth_it)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDate: String? = MyApp.getInstance().resources.getString(R.string.lbl_29_09_2023)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBalas: String? = MyApp.getInstance().resources.getString(R.string.lbl_balas)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCloserwedding: String? =
      MyApp.getInstance().resources.getString(R.string.msg_closerwedding)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.msg_terima_kasih_su)

)
