package com.paniroisapplication.app.modules.datasaya.`data`.model

import com.paniroisapplication.app.R
import com.paniroisapplication.app.appcomponents.di.MyApp
import kotlin.String

data class DataSayaModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtDataSaya: String? = MyApp.getInstance().resources.getString(R.string.lbl_data_saya)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPendapatan: String? = MyApp.getInstance().resources.getString(R.string.lbl_pendapatan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPenjualan: String? = MyApp.getInstance().resources.getString(R.string.lbl_penjualan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtProduk: String? = MyApp.getInstance().resources.getString(R.string.lbl_produk)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPengunjung: String? = MyApp.getInstance().resources.getString(R.string.lbl_pengunjung)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSemua: String? = MyApp.getInstance().resources.getString(R.string.lbl_semua)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHariini: String? = MyApp.getInstance().resources.getString(R.string.lbl_hari_ini2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBulanIni: String? = MyApp.getInstance().resources.getString(R.string.lbl_bulan_ini)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTahunIni: String? = MyApp.getInstance().resources.getString(R.string.lbl_tahun_ini)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTahunIniOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_tanggal_khusus)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPendapatanSaya: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_pendapatan_saya)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRpCounter: String? = MyApp.getInstance().resources.getString(R.string.lbl_rp_55_937_533)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGrafik: String? = MyApp.getInstance().resources.getString(R.string.lbl_grafik)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPendapatanTert: String? =
      MyApp.getInstance().resources.getString(R.string.msg_pendapatan_tert)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMei: String? = MyApp.getInstance().resources.getString(R.string.lbl_mei)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRpCounterOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_rp_13_004_864)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSeptember: String? = MyApp.getInstance().resources.getString(R.string.lbl_september)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRpCounterTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_rp_12_004_779)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAgustus: String? = MyApp.getInstance().resources.getString(R.string.lbl_agustus)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.lbl_rp_3_004_533)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtJuli: String? = MyApp.getInstance().resources.getString(R.string.lbl_juli)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguageOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_rp_1_004_245)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMaret: String? = MyApp.getInstance().resources.getString(R.string.lbl_maret)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguageTwo: String? = MyApp.getInstance().resources.getString(R.string.msg_rp_604_12)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtApril: String? = MyApp.getInstance().resources.getString(R.string.lbl_april)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguageThree: String? = MyApp.getInstance().resources.getString(R.string.msg_rp_531_00)

)
