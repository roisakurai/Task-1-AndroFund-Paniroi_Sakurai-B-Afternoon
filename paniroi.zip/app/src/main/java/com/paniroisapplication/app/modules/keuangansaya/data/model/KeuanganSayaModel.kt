package com.paniroisapplication.app.modules.keuangansaya.`data`.model

import com.paniroisapplication.app.R
import com.paniroisapplication.app.appcomponents.di.MyApp
import kotlin.String

data class KeuanganSayaModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtKeuanganSaya: String? = MyApp.getInstance().resources.getString(R.string.lbl_keuangan_saya)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSaldoSaya: String? = MyApp.getInstance().resources.getString(R.string.lbl_saldo_saya)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRpCounter: String? = MyApp.getInstance().resources.getString(R.string.lbl_rp_15_320_000)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLaporanKeuanga: String? =
      MyApp.getInstance().resources.getString(R.string.msg_laporan_keuanga)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSepanjangMasa: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_sepanjang_waktu)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHariIni: String? = MyApp.getInstance().resources.getString(R.string.lbl_hari_ini)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBulanIni: String? = MyApp.getInstance().resources.getString(R.string.lbl_bulan_ini)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTahunIni: String? = MyApp.getInstance().resources.getString(R.string.lbl_tahun_ini)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTampilkanlebih: String? =
      MyApp.getInstance().resources.getString(R.string.msg_tampilkan_lebih)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCatatanTransak: String? =
      MyApp.getInstance().resources.getString(R.string.msg_catatan_transak)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etOneValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etFourOneValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etFiveValue: String? = null
)
