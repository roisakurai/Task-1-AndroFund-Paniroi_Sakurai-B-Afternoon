package com.paniroisapplication.app.modules.dashboardvendorcontainer.ui

import android.os.Handler
import android.os.Looper
import androidx.activity.viewModels
import com.paniroisapplication.app.R
import com.paniroisapplication.app.appcomponents.base.BaseActivity
import com.paniroisapplication.app.databinding.ActivityDashboardVendorContainerBinding
import com.paniroisapplication.app.extensions.loadFragment
import com.paniroisapplication.app.modules.dashboardvendor.ui.DashboardVendorFragment
import com.paniroisapplication.app.modules.dashboardvendorcontainer.`data`.viewmodel.DashboardVendorContainerVM
import com.paniroisapplication.app.modules.produksaya.ui.ProdukSayaActivity
import kotlin.String
import kotlin.Unit

class DashboardVendorContainerActivity :
    BaseActivity<ActivityDashboardVendorContainerBinding>(R.layout.activity_dashboard_vendor_container)
    {
  private val viewModel: DashboardVendorContainerVM by viewModels<DashboardVendorContainerVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.dashboardVendorContainerVM = viewModel
    Handler(Looper.getMainLooper()).postDelayed( {
      val destIntent = ProdukSayaActivity.getIntent(this, null)
      startActivity(destIntent)
      finish()
      }, 3000)
      val destFragment = DashboardVendorFragment.getInstance(null)
      this.loadFragment(
          R.id.fragmentContainer,
          destFragment,
          bundle = destFragment.arguments, 
          tag = DashboardVendorFragment.TAG, 
          addToBackStack = false, 
          add = false, 
          enter = null, 
          exit = null, 
          )
    }

    override fun setUpClicks(): Unit {
      binding.imageContrast.setOnClickListener {
        val destFragment = DashboardVendorFragment.getInstance(null)
        this.loadFragment(
            R.id.fragmentContainer,
            destFragment,
            bundle = destFragment.arguments, 
            tag = DashboardVendorFragment.TAG, 
            addToBackStack = true, 
            add = false, 
            enter = null, 
            exit = null, 
            )
      }
    }

    companion object {
      const val TAG: String = "DASHBOARD_VENDOR_CONTAINER_ACTIVITY"

    }
  }
