package com.paniroisapplication.app.modules.produksaya.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.widget.SearchView
import com.paniroisapplication.app.R
import com.paniroisapplication.app.appcomponents.base.BaseActivity
import com.paniroisapplication.app.databinding.ActivityProdukSayaBinding
import com.paniroisapplication.app.modules.produksaya.`data`.model.ProdukSayaRowModel
import com.paniroisapplication.app.modules.produksaya.`data`.viewmodel.ProdukSayaVM
import kotlin.Boolean
import kotlin.Int
import kotlin.String
import kotlin.Unit

class ProdukSayaActivity : BaseActivity<ActivityProdukSayaBinding>(R.layout.activity_produk_saya) {
  private val viewModel: ProdukSayaVM by viewModels<ProdukSayaVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val produkSayaAdapter = ProdukSayaAdapter(viewModel.produkSayaList.value?:mutableListOf())
    binding.recyclerProdukSaya.adapter = produkSayaAdapter
    produkSayaAdapter.setOnItemClickListener(
    object : ProdukSayaAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ProdukSayaRowModel) {
        onClickRecyclerProdukSaya(view, position, item)
      }
    }
    )
    viewModel.produkSayaList.observe(this) {
      produkSayaAdapter.updateData(it)
    }
    binding.produkSayaVM = viewModel
    setUpSearchViewFormSearchDefListener()
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  fun onClickRecyclerProdukSaya(
    view: View,
    position: Int,
    item: ProdukSayaRowModel
  ): Unit {
    when(view.id) {
    }
  }

  private fun setUpSearchViewFormSearchDefListener(): Unit {
    binding.searchViewFormSearchDef.setOnQueryTextListener(object :
    SearchView.OnQueryTextListener {
      override fun onQueryTextSubmit(p0 : String) : Boolean {
        // Performs search when user hit
        // the search button on the keyboard
        return false
      }
      override fun onQueryTextChange(p0 : String) : Boolean {
        // Start filtering the list as user
        // start entering the characters
        return false
      }
      })
    }

    companion object {
      const val TAG: String = "PRODUK_SAYA_ACTIVITY"


      fun getIntent(context: Context, bundle: Bundle?): Intent {
        val destIntent = Intent(context, ProdukSayaActivity::class.java)
        destIntent.putExtra("bundle", bundle)
        return destIntent
      }
    }
  }
