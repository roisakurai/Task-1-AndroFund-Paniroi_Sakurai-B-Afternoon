package com.paniroisapplication.app.modules.produksaya.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.paniroisapplication.app.modules.produksaya.`data`.model.ProdukSayaModel
import com.paniroisapplication.app.modules.produksaya.`data`.model.ProdukSayaRowModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class ProdukSayaVM : ViewModel(), KoinComponent {
  val produkSayaModel: MutableLiveData<ProdukSayaModel> = MutableLiveData(ProdukSayaModel())

  var navArguments: Bundle? = null

  val produkSayaList: MutableLiveData<MutableList<ProdukSayaRowModel>> =
      MutableLiveData(mutableListOf())
}
